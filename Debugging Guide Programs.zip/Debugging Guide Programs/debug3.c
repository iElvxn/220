#include <stdlib.h>
#include <stdio.h>

#define debug(msg) printf("DEBUG: %s", msg)

int main(int argc, char *argv[]) {
	debug("Hello, World!\n");
	return EXIT_SUCCESS;
}
