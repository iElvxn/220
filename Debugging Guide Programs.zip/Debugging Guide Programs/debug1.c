#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int i = 0; 
    char *string = "Hello, World!";
    printf("%s\n", string);
    return EXIT_SUCCESS;
}